<?php

include_once 'navigacija.php';

include_once '../objects/countingItems.php';

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="../CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <main>
           
            <header class="kategorijos">
                   
                <div class="list-group" style="padding: 15px; margin-top: 70px;">
                    <a href="dzinsai.php"><input type="button" name='2' class="btn btn-outline-secondary" value="Dzinsai" style="width: 20%"></a>
                    <a href="marskineliai.php"><input type="button" name="marskineliai" class="btn btn-outline-secondary" value="Marskineliai" style="width: 20%"></a>
                    <a href="batai.php"><input type="button" name="batai" class="btn btn-outline-secondary" value="Batai" style="width: 20%"></a>
                    <a href="megztiniai.php"><input type="button" name="megztiniai" class="btn btn-outline-secondary" value="Megztiniai" style="width: 20%"></a>
                    <a href="kepures.php"><input type="button" name="kepures" class="btn btn-outline-secondary" value="Kepures" style="width: 20%"></a>
                </div>
            
            </header>
            
            <article>
                <?php
                    $query = "SELECT id, image, name, description, price FROM produktai WHERE Category_id=1 ORDER BY id ASC LIMIT 6";
                    $result = mysqli_query($connect, $query); 
                    if(mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_array($result)) {
                ?>
                
        <div class="col-md-2" style="display: inline-block; margin-left: 12%; margin-top: 100px; size: 50%">
            <form action="batai.php?action=add&id=<?php echo $row["id"]; ?>" method="POST">
  <div class="card-deck">
  <div class="card">
      <img src="../uploads/images/<?php echo $row['image']; ?>" class="card-img-top" alt="..." style="width: 200px; height: 200px;">
    <div class="card-body">
      <h5 class="card-title"><?php echo $row['name']; ?></h5>
      <p class="card-text"><?php echo $row['description']; ?></p>
    </div>
    <div class="card-footer">
        <div class="input-group input-group-sm mb-3">
            <input type="text" name="quantity" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value="1">
        </div>
        <input type="hidden" name="hidden_name" value="<?php echo $row['name']; ?>"/>
        <input type="hidden" name="hidden_price" value="<?php echo $row['price']; ?>"/>
        <h4><?php echo $row['price'] . "€"; ?></h4>
        <input type="submit" name="add_to_cart" class="btn btn-primary btn-sm" value="I krepseli"/>
      
    </div>
  </div>
  </div>
            </form>
        </div>
           
             
                <?php
                    }
                }
                    ?>
            </article>
        </main>
    </body>
</html>