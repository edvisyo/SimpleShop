<?php

include_once 'navigacija.php';

include 'objects/countingItems.php';

$link = mysqli_connect('localhost', 'root', '');
mysqli_select_db($link, 'onlineshop');

$results_per_page = 6;

$sql = "SELECT * FROM produktai";
$result = mysqli_query($link, $sql);
$number_of_results = mysqli_num_rows($result);

$number_of_pages = ceil($number_of_results/$results_per_page);

if(!isset($_GET['page'])) {
    $page = 1;
}   else {
    $page = $_GET['page'];
}

$this_page_first_result = ($page-1)*$results_per_page;

$sql = "SELECT id, image, name, description, price FROM produktai ORDER BY id ASC LIMIT " . $this_page_first_result . ',' . $results_per_page;
$result = mysqli_query($link, $sql);
//while ($row = mysqli_fetch_array($result)) {
    //echo $row['id'] . $row['name'] . ' ' . $row['description'] . ' ' . $row['price'] . "€";
//}

//for ($page = 1; $page <= $number_of_pages; $page++) {
    //echo '<a href="pagination.php?page=' . $page . '">' . $page . '</a>';
//}
     
?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <main>
            <?php while ($row = mysqli_fetch_array($result)) { ?>
            <form action="pagination.php?action=add&id=<?php echo $row["id"]; ?>" method="POST">
        <div class="col-md-2" style="display: inline-block; margin-left: 12%; margin-top: 100px; size: 50%">
  <div class="card-deck">
  <div class="card">
      <img src="uploads/images/<?php echo $row['image']; ?>" class="card-img-top" alt="..." style="width: 200px; height: 200px;">
    <div class="card-body">
      <h5 class="card-title"><?php echo $row['name']; ?></h5>
      <p class="card-text"><?php echo $row['description']; ?></p>
    </div>
    <div class="card-footer">
        <div class="input-group input-group-sm mb-3">
            <input type="text" name="quantity" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value="1">
        </div>
        <input type="hidden" name="hidden_name" value="<?php echo $row['name']; ?>"/>
        <input type="hidden" name="hidden_price" value="<?php echo $row['price']; ?>"/>
        <h4><?php echo $row['price'] . "€"; ?></h4>
        <input type="submit" name="add_to_cart" class="btn btn-primary btn-sm" value="I krepseli"/>
      
    </div>
  </div>
  </div>
        </div>
                
            <?php } ?>
                </form>
        </main>
        <footer class="footerNav">
<nav aria-label="Page navigation example">        
  <ul class="pagination justify-content-center">
    <li class="page-item">
        <a class="page-link" href="index.php" tabindex="-1" aria-disabled="true">First</a>
    </li>
    <?php for ($page = 1; $page <= $number_of_pages; $page++) { ?>
    <li class="page-item"><a class="page-link" <?php echo '<a href="pagination.php?page=' . $page . '">' . $page . '</a>'; ?></a></li>
    <?php } ?>
    <li class="page-item">
      <a class="page-link" href="#">Last</a>
    </li>
  </ul>         
</nav>
        </footer>
    </body>
</html>

    