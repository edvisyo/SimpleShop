<?php

class connection {
    
    
    public $connection;
    
    function __construct($database_hostname, $database_username, $database_password, $database_name) {
        $this->connection = mysqli_connect($database_hostname, $database_username, $database_password, $database_name);
        
        if(mysqli_connect_errno()) {
            printf("Database Connection ERROR!: %s\n", mysqli_connect_error());
            exit();
        } else {
            mysqli_set_charset($this->connection, "utf-8");  
        }
    }
    
    function isUnique($entry, $table, $field) {
        $query = "SELECT * FROM " . $table . " WHERE " . $field . " = '" . $entry . "' LIMIT 1";
        $res = mysqli_query($this->connection, $query);
        
        if ($res) {
            if (mysqli_num_rows($res) > 0) {
                return false;
            } else {
                return true;
            }
        } else {
            printf("DB QUERRY ERROR: %s\n", mysqli_error($this->connection));
            exit();
        }
    }
    
    function registerUser($firstname, $lastname, $username, $email, $password) {
        $query = "INSERT INTO vartotojai (Vardas, Pavarde, VartotojoVardas, El_pastas, Slaptazodis) VALUES ('" . $firstname . "', '" . $lastname . "', '" . $username . "' , '" . $email . "', '" . $password . "')";
        $res = mysqli_query($this->connection, $query);
        
        if($res) {
            return true;
        } else {
           printf("DB INSERT ERROR: %s\n", mysqli_error($this->connection));
            exit(); 
        }
    }
    
    function loginUser($username, $password) {
        $query = "SELECT * FROM vartotojai WHERE VartotojoVardas = '" . $username . "' AND Slaptazodis = '" . $password . "' LIMIT 1";
        $res = mysqli_query($this->connection, $query);

        if ($res) {
            if (mysqli_num_rows($res) > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            printf("DB QUERRY ERROR: %s\n", mysqli_error($this->connection));
            exit();
        }
    }
    
    function getUserId($username) {
        $query = "SELECT id FROM vartotojai WHERE VartotojoVardas = '" . $username . "' LIMIT 1";
        $res = mysqli_query($this->connection, $query);

        if ($res) {
            if (mysqli_num_rows($res) != 0) {
                return $res->fetch_object()->id;
            } else {
                return false;
            }
        } else {
            printf("DB SELECT ERROR: %s\n", mysqli_error($this->connection));
            exit();
        }
    }

 }
    





