<?php

include 'user_settings.php';

if(filter_has_var(INPUT_POST, "email") && filter_has_var(INPUT_POST, "newemail") && filter_has_var(INPUT_POST, "newemail2")) { 
    
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_STRING);
    $newemail = filter_input(INPUT_POST, "newemail", FILTER_SANITIZE_STRING);
    $newemail2 = filter_input(INPUT_POST, "newemail2", FILTER_SANITIZE_STRING);
    
    include_once 'inc/variables.php';
    include 'config/emailchange.php';
    $connection = new newEmail($database_hostname, $database_username, $database_password, $database_name);
    
    $errors = array();

    if (empty($email)) {
        array_push($errors, "Esamas elektroninis paštas negali būti tuščias!");
    }

    if (empty($newemail)) {
        array_push($errors, "Naujas elektroninis paštas negali būti tuščias!");
    } 
    
    if (empty($newemail2)) {
        array_push($errors, "Elektroninio pašto pakartojimas negali būti tuščias!");
    }   else if (!$connection->isUnique($newemail2, 'vartotojai', 'El_pastas')) {
        array_push($errors, "Elektroninio pašto pakeitimas neimanomas! Toks paštas jau egzistuoja!");
    }
    
    if (count($errors) == 0) {

        $result = $connection->emailChange($newemail2);
        if ($result) {

        $success = TRUE;
        
        } else {
            printf("EMAIL CHANGE ERROR!");
            exit();
        }
    }

}

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>        
        <form action="email_change.php" method="POST" class="username_passwd_Change">
            <h5>Pažymėtus laukelius * būtina užpildyti!</h5>
            <?php if (isset($success) && $success == TRUE) { ?>
                <div class="alertmsg">
                    Elektroninis paštas sekmingai pakeistas!
                    <div><a href="email_change.php"></a></div>
                </div>
            <?php } ?>
            <br>
            <?php if (isset($errors) && count($errors) > 0) { ?>
            <?php foreach ($errors AS $value) { ?>
            <?php echo $value; ?>
            <?php } ?>
            <?php } ?>
            <br>
            <br>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Esamas El.paštas* </span>
  </div>
                <input type="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="email">
</div>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Naujas El.paštas* </span>
  </div>
  <input type="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="newemail">
</div>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Pakartokite* </span>
  </div>
                <input type="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="newemail2">
</div>
            <input type="submit" class="btn btn-success" value="Keisti">
        </form>
    </body>
</html>
