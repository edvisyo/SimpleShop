<?php include_once 'navigacija.php'; ?>

<?php

$link = mysqli_connect('localhost', 'root', '');
mysqli_select_db($link, 'onlineshop');

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <div class="uzsakymas">
        <h3>Uzsakymo aprasymas:</h3>
        <div class="table-responsive">
            <table class="table table-bordered">
                <tr>
                    <th width="40%">Prekes pavadinimas:</th>
                    <th width="10%">Kiekis:</th>
                    <th width="20%">Kaina:</th>
                    <th width="15%">Visu prekiu kaina:</th>
                    <th width="5%">Busena:</th>
                </tr>
                <?php
                if(!empty($_SESSION["shopping_cart"])) {
                    $total = 0;
                    foreach ($_SESSION["shopping_cart"] as $keys => $values) {
                ?>
                <tr>
                    <td><?php echo $values["item_name"]; ?></td>
                    <td><?php echo $values["item_quantity"]; ?></td>
                    <td><?php echo $values["item_price"]. "€"; ?></td>
                    <td><?php echo number_format($values["item_quantity"] * $values["item_price"], 2). "€"; ?></td>
                    <td><a href="index.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Pasalinti</span></a></td>
                </tr>
                <?php
                    $total = $total + ($values["item_quantity"] * $values["item_price"]);
                    }
                ?>
                <tr>
                    <td colspan="3" align="right">Pilna kaina</td>
                    <td align="right"><?php echo number_format($total, 2). "€"; ?></td>
                </tr>
                <?php
                }
                ?>
            </table> 
        </div>
        </div>
    </body>
</html>
  

