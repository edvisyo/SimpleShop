-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2019 at 12:03 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `ID` int(11) NOT NULL,
  `Vardas` varchar(45) NOT NULL,
  `el_pastas` varchar(45) NOT NULL,
  `Pastabos` varchar(455) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`ID`, `Vardas`, `el_pastas`, `Pastabos`) VALUES
(3, 'admin', 'admin@test.com', 'Test Post'),
(4, 'admin2', 'admin2@test.com', 'Second test post!');

-- --------------------------------------------------------

--
-- Table structure for table `kategorijos`
--

CREATE TABLE `kategorijos` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Created` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategorijos`
--

INSERT INTO `kategorijos` (`ID`, `Name`, `Created`, `Modified`) VALUES
(1, 'Batai', '2019-04-10 00:03:11', '2019-04-11 16:28:35'),
(2, 'Dzinsai', '2019-04-10 00:02:41', '2019-04-11 16:38:15'),
(3, 'Marskineliai', '2019-04-10 00:05:42', '2019-04-11 16:58:15'),
(4, 'Kepures', '2019-04-10 00:07:45', '2019-04-11 17:41:23'),
(5, 'Megztiniai', '2019-04-10 00:10:32', '2019-04-11 16:41:35');

-- --------------------------------------------------------

--
-- Table structure for table `krepselis`
--

CREATE TABLE `krepselis` (
  `ID` int(11) NOT NULL,
  `User_id` int(11) NOT NULL,
  `Product_id` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Created` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `produktai`
--

CREATE TABLE `produktai` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Price` double NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Category_id` int(11) NOT NULL,
  `Created` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produktai`
--

INSERT INTO `produktai` (`ID`, `Name`, `Description`, `Price`, `Image`, `Category_id`, `Created`, `Modified`) VALUES
(1, 'Stussy marskineliai Basic Tee White', 'lorem ipsum', 10.89, 'Stussy_id1.jpg', 3, '2019-04-11 01:12:26', '2019-04-16 13:08:42'),
(2, 'Fila Men Day Tee Black Iris-True Red-Bright White', 'lorem ipsum', 10.99, 'fila_id2.jpg', 3, '2019-04-11 01:12:46', '2019-04-16 13:08:52'),
(3, 'CHEAP MONDAY Tight Pure Blue Jeans', 'lorem ipsum', 28.39, 'dzinsai_id1.jpg', 2, '2019-04-11 02:12:46', '2019-04-16 13:18:52'),
(4, 'Glendale Cap Black/Checkerboard', 'lorem ipsum', 30.99, 'herschel_id1.jpg', 4, '2019-04-11 01:12:26', '2019-04-16 13:18:52'),
(5, 'Nike Stefan Janoski Tie Dye (GS)', 'lorem ipsum', 60.99, 'nike_id2.jpg', 1, '2019-04-11 01:12:26', '2019-04-16 13:28:27'),
(6, 'Fila Women Julianne Varity Crew', 'lorem ipsum', 60.59, 'fila_megztinis.jpg', 5, '2019-04-11 01:12:26', '2019-04-16 13:28:27'),
(7, 'Warrior Man Bucket Hat Black', 'lorem ipsum', 50.59, 'stussy_kepure.jpg', 4, '2019-04-11 01:12:26', '2019-04-16 13:44:49'),
(8, 'Adidas Trefoil Hoodie Power Red', 'lorem ipsum', 65.99, 'adidas_megztinis.jpg', 5, '2019-04-11 01:12:26', '2019-04-16 13:44:49'),
(9, 'KR3W Black Jeans', 'KR3W dzinsai yra pagaminti is medvilnes, poliester...', 60.99, 'crew_dzinsai.jpg', 2, '2019-04-11 01:12:26', '2019-04-16 13:48:56'),
(10, 'Adidas Trefoil T-Shirts White', 'lorem ipsum', 12.89, 'adidas_marskineliai.jpg', 3, '2019-04-11 01:12:26', '2019-04-16 13:48:56'),
(11, 'Fila Sail Bucket Hat Bright White', 'lorem ipsum', 32.49, 'fila_kepure.jpg', 4, '2019-04-11 01:12:26', '2019-04-20 09:13:10'),
(12, 'New Balance Numeric 255', 'lorem ipsum', 70.89, 'newballance_batai.jpg', 1, '2019-04-11 01:12:26', '2019-04-16 13:51:50'),
(13, 'Magenta Jungle 2 Tee Black', 'lorem ipsum', 15.45, 'magenta_marskineliai.jpg', 3, '2019-04-11 01:12:26', '2019-04-20 09:07:49'),
(14, 'Makia Slim Fit Jeans Grey', 'Makia Slim Fit Jeans Grey pilki vyriski dzinsai.', 60.99, 'makia_dzinsai.jpg', 2, '2019-04-11 01:12:26', '2019-04-20 09:07:49'),
(15, 'Vans MN Drop V II Snapback Black/White', 'lorem ipsum', 35.79, 'vans_kepure.jpg', 4, '2019-04-11 01:12:26', '2019-04-20 09:12:41'),
(16, 'Polar Signature Crewneck - Black', 'lorem ipsum', 70.89, 'polar_megztinis.jpg', 5, '2019-04-11 01:12:26', '2019-04-20 09:12:41'),
(17, 'Polar 90s Jeans - Light Blue', 'lorem ipsum', 80.39, 'polar_dzinsai.jpg', 2, '2019-04-11 01:12:26', '2019-04-20 09:17:35'),
(18, 'Nike Air Kedai', 'Laisvalaikio batai Nike Air Force.', 83.99, 'nike_batai.jpg', 1, '2019-04-11 01:12:26', '2019-04-20 09:21:12'),
(19, 'HUF Hooded Zipper Disaster Ops Triangle', 'lorem ipsum', 49.99, 'huf_megztinis.jpg', 5, '2019-04-11 01:12:26', '2019-04-20 09:20:53'),
(20, 'Huf T-Shirt The Lick Cloud Blue', 'lorem ipsum', 16.1, 'huf_marskineliai.jpg', 3, '2019-04-11 01:12:26', '2019-04-20 09:20:53'),
(21, 'HUF kepure', 'lorem ipsum', 19.99, 'huf_kepure.jpg', 4, '2019-04-11 01:12:26', '2019-04-20 09:23:36'),
(22, 'Nike SB', 'Nike SB Koston HyperVulc sportiniai bateliai vyrams..', 59.89, 'nikeSB_batai.jpg', 1, '2019-04-11 01:12:26', '2019-04-20 09:23:36'),
(23, 'Thrasher Skate Mag Crew Black', 'lorem ipsum', 50.99, 'trasher_megztinis.jpg', 5, '2019-04-11 01:12:26', '2019-04-20 09:28:19'),
(24, 'Thrasher T-Shirt Skate Mag White', 'lorem ipsum', 15.79, 'trasher_marskineliai.jpg', 3, '2019-04-11 01:12:26', '2019-04-20 09:28:19');

-- --------------------------------------------------------

--
-- Table structure for table `vartotojai`
--

CREATE TABLE `vartotojai` (
  `ID` int(11) NOT NULL,
  `Vardas` varchar(20) NOT NULL,
  `Pavarde` varchar(20) NOT NULL,
  `VartotojoVardas` varchar(20) NOT NULL,
  `El_pastas` varchar(20) NOT NULL,
  `Slaptazodis` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vartotojai`
--

INSERT INTO `vartotojai` (`ID`, `Vardas`, `Pavarde`, `VartotojoVardas`, `El_pastas`, `Slaptazodis`) VALUES
(1, 'test', 'test', 'test2', 'test@test.com', 'test'),
(2, 'test1', 'test1', 'test1', 'test1@test.com', 'test1'),
(3, 'test11', 'test11', 'admin', 'admin@admin.com', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `kategorijos`
--
ALTER TABLE `kategorijos`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `krepselis`
--
ALTER TABLE `krepselis`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `produktai`
--
ALTER TABLE `produktai`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vartotojai`
--
ALTER TABLE `vartotojai`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kategorijos`
--
ALTER TABLE `kategorijos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `krepselis`
--
ALTER TABLE `krepselis`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `produktai`
--
ALTER TABLE `produktai`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `vartotojai`
--
ALTER TABLE `vartotojai`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
