<?php

session_start();

if (isset($_SESSION["logged_in"])) {

    include_once '../inc/variables.php';

    include_once '../config/database.php';
    $connection = new connection($database_hostname, $database_username, $database_password, $database_name);

    if (filter_has_var(INPUT_POST, "logout")) {
        session_destroy();
        header('location: ../prisijungimas.php');
    }

?>



<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="../CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <form action="navigacija.php" method="POST">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="../index.php" style="color: red;">OnlineShop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
          <a class="nav-link" href="../index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="../katalogas.php">Katalogas</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="../blog/blog_page.php">Blogas</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="../user_settings.php">Vartotojo Nustatymai</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="../krepselis.php">Krepselis</a>
      </li>
      <div class="rightPosition">
      <li class="nav-item">
          <a class="nav-link" href="../prisijungimas.php" id="prisijungimas">Prisijungimas</a>
      </li>
      </div>
      <li class="nav-item">
          <a class="nav-link" href="../registracija.php">Registracija</a>
      </li>
      <div class="username">
      <li class="nav-item">
          <h5 style="color: purple;"><?php echo $_SESSION['username'] ?></h5>
      </li>
      </div>
      <div class="atsijungti">
      <li class="nav-item">
          <input type="submit" name="logout" class="btn btn-primary btn-sm" value="Atsijungti">
      </li>
      </div>
    </ul>
  </div>
</nav>
            </form>
    </body>
</html>

<?php
} else {
    header('location: ../prisijungimas.php');
}
