<?php

include 'navigacija.php';

$connect = mysqli_connect('localhost', 'root', '', 'onlineshop');

if(filter_has_var(INPUT_POST, "name") && filter_has_var(INPUT_POST, "email") && filter_has_var(INPUT_POST, "text")) {
    
    $name = filter_input(INPUT_POST, "name", FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_STRING);
    $text = filter_input(INPUT_POST, "text", FILTER_SANITIZE_STRING);

$sql = "INSERT INTO blog (Vardas, el_pastas, Pastabos) VALUES ('" . $name . "', '" . $email . "', '" . $text . "')";
if($connect->query($sql) === TRUE) {
    echo '<script>alert("Aciu uz jusu nuomone!")</script>';
    echo '<script>window.location="blog_page.php"</script>';
}   else {
    echo "Error: " . $sql . "<br>" . $connect->error;
}
}
?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        
        <div class="blogPost">
            <h2><strong>Jūsų nuomonė mums svarbi!</strong></h2>
        <form action="blog_post.php" method="POST">
  <div class="form-group">
    <label for="exampleFormControlInput1">Jūsų vardas:</label>
    <input type="name" class="form-control" id="exampleFormControlInput1" name="name" placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Jūsų elektroninis paštas:</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" name="email" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Jūsų pastabos:</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" name="text" rows="9"></textarea>
  </div>
     <input class="btn btn-primary" type="submit" value="Pateikti">
</form>
        </div>
    </body>
</html>
