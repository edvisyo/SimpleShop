<?php
include_once 'navigacija.php';

$connect = mysqli_connect('localhost', 'root', '', 'onlineshop');

$query = "SELECT Vardas, el_pastas, Pastabos FROM blog";
$result = mysqli_query($connect, $query);

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <?php        while ($row = mysqli_fetch_array($result)) { ?>
        <div class="jumbotron jumbotron-fluid">
        <div class="container" style="text-align: left;">
            <h3 class="display-4"><?php echo $row['Vardas']; ?></h3>
            <h4><?php echo $row['el_pastas']; ?></h4>
            <p class="lead"><?php echo $row['Pastabos']; ?></p>
        </div>
    </div>
       <?php } ?>
        <h5>Jeigu norite pateikti savo atsiliepimą spauskite <a href="blog_post.php">Čia!</a></h5>
    </body>
</html>

