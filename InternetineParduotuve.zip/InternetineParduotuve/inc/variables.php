<?php

$database_hostname = 'localhost';
$database_username = 'root';
$database_password = '';
$database_name = 'onlineshop';

$firstname_length = 20;
$lastname_length = 20;
$username_length = 20;
$email_length = 20;
$password_length = 50;

$currency_symbol = "€";
$max_order_amount = 10;
$discount_treshold = 10;
$discount_amount = 0.05;
