<?php

include 'user_settings.php';

if(filter_has_var(INPUT_POST, "vartvardas") && filter_has_var(INPUT_POST, "newname") && filter_has_var(INPUT_POST, "newname2")) { 
    
    $vartvardas = filter_input(INPUT_POST, "vartvardas", FILTER_SANITIZE_STRING);
    $newname = filter_input(INPUT_POST, "newname", FILTER_SANITIZE_STRING);
    $newname2 = filter_input(INPUT_POST, "newname2", FILTER_SANITIZE_STRING);
    
    include_once 'inc/variables.php';
    include 'config/usernamechange.php';
    $connection = new newUserName($database_hostname, $database_username, $database_password, $database_name);
    
    $errors = array();

    if (empty($vartvardas)) {
        array_push($errors, "Esamas vartotojo vardas negali būti tuščias!");
    }

    if (empty($newname)) {
        array_push($errors, "Naujas vartotojo vardas negali būti tuščias!");
    } 
    
    if (empty($newname2)) {
        array_push($errors, "Vardo pakartojimas negali būti tuščias!");
    }   else if (!$connection->isUnique($newname2, 'vartotojai', 'VartotojoVardas')) {
        array_push($errors, "Vardo pakeitimas neimanomas! Toks vartotojas jau egzistuoja!");
    }
    
    if (count($errors) == 0) {

        $result = $connection->nameChange($newname2);
        if ($result) {

        $success = TRUE;
        $_SESSION['username'] = $_POST['newname2'];
        } else {
            printf("USERNAME CHANGE ERROR!");
            exit();
        }
    }

}

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>        
        <form action="username_change.php" method="POST" class="username_passwd_Change">
            <h5>Pažymėtus laukelius * būtina užpildyti!</h5>
            <?php if (isset($success) && $success == TRUE) { ?>
                <div class="alertmsg">
                    Vartotojo vardas sekmingai pakeistas!
                    <div><a href="username_change.php"></a></div>
                </div>
            <?php } ?>
            <br>
            <?php if (isset($errors) && count($errors) > 0) { ?>
            <?php foreach ($errors AS $value) { ?>
            <?php echo $value; ?>
            <?php } ?>
            <?php } ?>
            <br>
            <br>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Esamas vardas* </span>
  </div>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="vartvardas">
</div>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Naujas vardas* </span>
  </div>
  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="newname">
</div>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Pakartokite* </span>
  </div>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="newname2">
</div>
            <input type="submit" class="btn btn-success" value="Keisti">
        </form>
    </body>
</html>

