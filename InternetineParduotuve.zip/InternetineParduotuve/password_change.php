<?php

include 'user_settings.php';

if (filter_has_var(INPUT_POST, "oldpass") && filter_has_var(INPUT_POST, "newpass1") && filter_has_var(INPUT_POST, "newpass2")) {

    $oldpass = filter_input(INPUT_POST, "oldpass", FILTER_SANITIZE_STRING);
    $newpass1 = filter_input(INPUT_POST, "newpass1", FILTER_SANITIZE_STRING);
    $newpass2 = filter_input(INPUT_POST, "newpass2", FILTER_SANITIZE_STRING);
    
    include_once 'inc/variables.php';
    include 'config/passwordchange.php';
    $connection = new newPassword($database_hostname, $database_username, $database_password, $database_name);
    
    $errors = array();

    if (empty($oldpass)) {
        array_push($errors, "Esamas slaptažodis negali būti tuščias!");
    }

    if (empty($newpass1)) {
        array_push($errors, "Naujas slaptažodis negali būti tuščias!");
    } 
    
    if (empty($newpass2)) {
        array_push($errors, "Slaptažodzio pakartojimas negali būti tuščias!");
    }   //else if (!$connection->isUnique($newpass2, 'vartotojai', 'Slaptazodis')) {
        //array_push($errors, "Slaptazodzio pakeitimas neimanomas! Toks slaptazodis jau egzistuoja!");
    //}
    
    if (count($errors) == 0) {

        $result = $connection->passwordChange($newpass2);
        if ($result) {

        $success = TRUE;
       
        } else {
            printf("PASSWORD CHANGE ERROR!");
            exit();
        }
    }
    
}
?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <form action="password_change.php" method="POST" class="username_passwd_Change">
            <h5>Pažymėtus laukelius * būtina užpildyti!</h5>
            <?php if (isset($success) && $success == TRUE) { ?>
                <div class="alertmsg">
                    Slaptazodis sekmingai pakeistas!
                    <div><a href="password_change.php"></a></div>
                </div>
            <?php } ?>
            <br>
            <?php if (isset($errors) && count($errors) > 0) { ?>
            <?php foreach ($errors AS $value) { ?>
            <?php echo $value; ?>
            <?php } ?>
            <?php } ?>
            <br>
            <br>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Esamas slaptažodis* </span>
  </div>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="oldpass">
</div>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Naujas slaptažodis* </span>
  </div>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="newpass1">
</div>
            <div class="input-group mb-3">
  <div class="input-group-prepend">
      <span class="input-group-text" id="inputGroup-sizing-default" style="width: 160px;">Pakartokite* </span>
  </div>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="newpass2">
</div>
            <input type="submit" class="btn btn-success" value="Keisti">
        </form>
    </body>
</html>
