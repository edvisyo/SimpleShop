<?php

if (filter_has_var(INPUT_POST, "firstname") && filter_has_var(INPUT_POST, "lastname") && filter_has_var(INPUT_POST, "username") && filter_has_var(INPUT_POST, "email") && filter_has_var(INPUT_POST, "password") && filter_has_var(INPUT_POST, "password2")) {

    
    $firstname = filter_input(INPUT_POST, "firstname", FILTER_SANITIZE_STRING);
    $lastname = filter_input(INPUT_POST, "lastname", FILTER_SANITIZE_STRING);
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_STRING);
    $password2 = filter_input(INPUT_POST, "password2", FILTER_SANITIZE_STRING);

    include_once './inc/variables.php';

    include 'config/database.php';
    $connection = new connection($database_hostname, $database_username, $database_password, $database_name);

    $errors = array();

    if (empty($firstname)) {
        array_push($errors, "Vardas negali būti tuščias!");
    } else if (strlen($firstname) > $firstname_length) {
        array_push($errors, "Vardas negali būti ilgesnis negu " . $firstname_length . " simbolių!");
    }

    
    if (empty($lastname)) {
        array_push($errors, "Pavardė negali būti tuščia");
    } else if (strlen($lastname) > $lastname_length) {
        array_push($errors, "Pavardė negali būti ilgesnė negu " . $lastname_length . " simbolių!");
    }

   
    if (empty($username)) {
        array_push($errors, "Vartotojo vardas negali būti tuščias!");
    } else if (strlen($username) > $username_length) {
        array_push($errors, "Vartotojo vardas negali būti ilgesnis negu " . $username_length . " simbolių!");
    } else if (!$connection->isUnique($username, 'vartotojai', 'VartotojoVardas')) {
        array_push($errors, "Toks vartotojas jau egzistuoja!");
    }

    if (empty($email)) {
        array_push($errors, "El. Paštas negali būti tuščias!");
    } else if (strlen($email) > $email_length) {
        array_push($errors, "El. Paštas negali būti ilgesnis negu " . $email_length . " simbolių!");
    } else if (!$connection->isUnique($email, 'vartotojai', 'El_pastas')) {
        array_push($errors, "Vartotojas su tokiu elektroniniu paštu jau egzistuoja!");
    }

    if (empty($password)) {
        array_push($errors, "Slaptažodis negali būti tuščias!");
    } else if (strlen($password) > $password_length) {
        array_push($errors, "Slaptažodis negali būti ilgesnis negu " . $password_length . " simbolių!");
    } else if (empty($password2)) {
        array_push($errors, "Pakartotinas slaptažodis negali būti tuščias!");
    } else if ($password != $password2) {
        array_push($errors, "Slaptažodžiai nesutampa!");
    }

    if (count($errors) == 0) {

        $result = $connection->registerUser($firstname, $lastname, $username, $email, $password);
        if ($result) {

        $success = TRUE;
        } else {
            printf("REGISTER ERROR");
            exit();
        }
    }
}
?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <header class="registrationForm">
            <h1>Registracija</h1>
            <br>
            <?php if (isset($success) && $success == TRUE) { ?>
                <div class="alertmsg">
                    Registracija sėkminga!
                    Po 5 sekundžių būsite nukreipti į prisijungimą.
                    <div><a href="prisijungimas.php"></a></div>
                </div>
                <?php header("Refresh:5; url=prisijungimas.php", true, 303); ?>
            <?php } ?>
            <?php if (isset($errors) && count($errors) > 0) { ?>
            <?php foreach ($errors AS $value) { ?>
            <?php echo $value; ?>
            <?php } ?>
            <?php } ?>
            <br>
            <br>
   <form action="registracija.php" method="POST">
    <div class="form-group row">
    <label for="inputName3" class="col-sm-2 col-form-label">Vardas</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="firstname" id="inputName3" placeholder="Jusu vardas">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputSurname3" class="col-sm-2 col-form-label">Pavarde</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="lastname" id="inputSurname3" placeholder="Jusu pavarde">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputUsername3" class="col-sm-2 col-form-label">Vartotojas</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="username" id="inputUsername3" placeholder="Vartotojo Vardas">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">El.pastas</label>
    <div class="col-sm-10">
        <input type="email" class="form-control" name="email" id="inputEmail3" placeholder="Elektroninis pastas">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Slaptazodis</label>
    <div class="col-sm-10">
        <input type="password" class="form-control" name="password" id="inputPassword3" placeholder="Slaptazodis">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Slaptazodis</label>
    <div class="col-sm-10">
        <input type="password" class="form-control" name="password2" id="inputPassword3" placeholder="Pakartokite slaptazodi">
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
        </header>
    </body>
</html>

