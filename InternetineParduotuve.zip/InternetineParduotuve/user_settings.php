<?php

include 'navigacija.php';

if (filter_has_var(INPUT_POST, "logout")) {
        session_destroy();
        header('location: prisijungimas.php');
    }

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <form action="user_settings.php" method="POST"  class="userSettings">
        <div class="card mb-3" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
        <img src="uploads/images/user.png" class="card-img" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Hello, <?php echo $_SESSION['username']; ?>!</h5>
        <ul>
            <li><a href="logout.php">Atsijungti</a></li>
            <li><a href="username_change.php">Keisti varda</a></li>
            <li><a href="password_change.php">Keisti slaptazodi</a></li>
            <li><a href="email_change.php">Keisti elektronini pasta</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
            </form>
    </body>
</html>

