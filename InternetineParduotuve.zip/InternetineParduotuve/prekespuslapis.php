<?php

include_once 'navigacija.php';


$link = mysqli_connect('localhost', 'root', '');
mysqli_select_db($link, 'onlineshop');

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <main>
            <header class="prekesAprasymas">
            <form action="prekespuslapis.php?action=add&id=<?php echo $row["id"]; ?>" method="POST">
                <div class="jumbotron">
                    <div class="card" style="width: 18rem;">
                        <img src="..." class="card-img-top" alt="...">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    </div>
                    <h1 class="display-4">...</h1>    
                <h3 class="display-5">...</h3>
                <hr class="my-4">
                <p>...</p>
                <input type="submit" name="add_to_cart" class="btn btn-primary btn-md" value="I krepseli"/>
                </div>
            </form>
            </header>>
        </main>
    </body>
</html>