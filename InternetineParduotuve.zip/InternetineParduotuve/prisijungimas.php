<?php

session_start();

if(isset($_SESSION['logged_in'])) {
    header('location: index.php');
}

 if (filter_has_var(INPUT_POST, 'username') && filter_has_var(INPUT_POST, 'password')) {

    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_STRING);

    include './inc/variables.php';

    $errors = array();

    if (empty($username)) {
        array_push($errors, "Vartotojo vardas negali būti tuščias!");
    } else if (strlen($username) > $username_length) {
        array_push($errors, "Vartotojo vardas negali būti ilgesnis negu " . $username_length . " simbolių!");
    }

    if (empty($password)) {
        array_push($errors, "Slaptažodis negali būti tuščias!");
    } else if (strlen($password) > $password_length) {
        array_push($errors, "Slaptažodis negali būti ilgesnis negu " . $password_length . " simbolių!");
    }

    if (count($errors) == 0) {

        include 'config/database.php';
        $connection = new connection($database_hostname, $database_username, $database_password, $database_name);


        if ($connection->loginUser($username, $password)) {

            $success = TRUE;

            $_SESSION["logged_in"] = TRUE;
            $_SESSION["user_id"] = $connection->getUserId($username);
            $_SESSION["username"] = $username;
            $_SESSION["password"] = $password;

            $_COOKIE["username"] = $username;

            header('location: index.php');
        } else {
            array_push($errors, "Neteisingas vartotojo vardas arba slaptažodis!");
        }
    }
}

?>

<!DOCTYPE html>

<html lang="lt">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/mystyle.css">
        <title>Internetine Parduotuve</title>
    </head>
    <body>
        <header class="registrationForm">
            <h1>Prisijungimas</h1>
            <br>
        <?php if (isset($errors) && count($errors) > 0) { ?>
        <?php foreach ($errors AS $value) { ?>
        <?php echo $value; ?>
        <?php } ?>
        <?php } ?>
  <form action="prisijungimas.php" method="POST">
  <div class="form-group row">
    <label for="inputUsername3" class="col-sm-2 col-form-label">Vartotojas</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="username" id="inputUsername3" placeholder="Vartotojo Vardas">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Slaptazodis</label>
    <div class="col-sm-10">
        <input type="password" class="form-control" name="password" id="inputPassword3" placeholder="Slaptazodis">
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Sign in</button>
    </div>
  </div>
      <div class="form-group row">
          <a class="nav-link" href="registracija.php">Registracija</a>
      </div>
</form>
        </header>
    </body>
</html>
