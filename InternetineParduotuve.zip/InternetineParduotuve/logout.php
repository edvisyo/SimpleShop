<?php

session_start();
session_destroy();
header('Location: prisijungimas.php');
exit;

